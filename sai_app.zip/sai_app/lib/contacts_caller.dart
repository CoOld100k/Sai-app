import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:fuzzywuzzy/fuzzywuzzy.dart';
import 'package:permission_handler/permission_handler.dart';

/// Result of trying to resolve a spoken name to a contact.
class ContactMatch {
  final Contact contact;
  final int score; // 0-100, higher = better match
  ContactMatch(this.contact, this.score);
}

/// Handles the "اتصل بـ [Name]" ("call [Name]") voice command end-to-end:
/// permission check -> offline fuzzy name search -> direct native dial.
///
/// All contact data stays on-device; this class never touches the network.
class ContactsCaller {
  ContactsCaller._();
  static final ContactsCaller instance = ContactsCaller._();

  static const _callChannel = MethodChannel('com.sai.app/direct_call');

  List<Contact>? _cache;

  Future<bool> _ensurePermissions() async {
    final contacts = await Permission.contacts.request();
    final phone = await Permission.phone.request();
    return contacts.isGranted && phone.isGranted;
  }

  Future<List<Contact>> _loadContacts({bool forceRefresh = false}) async {
    if (_cache != null && !forceRefresh) return _cache!;
    _cache = await FlutterContacts.getContacts(
      withProperties: true,
      withPhoto: false,
    );
    return _cache!;
  }

  /// Parses a raw voice-recognized command like "اتصل بـ أحمد" or
  /// "call Ahmed" and extracts the spoken name portion.
  String? extractNameFromCommand(String command) {
    final normalized = command.trim();

    final patterns = <RegExp>[
      RegExp(r'اتصل\s*ب[ـ]?\s*(.+)', caseSensitive: false), // اتصل بـ فلان
      RegExp(r'كلم\s+(.+)', caseSensitive: false), // كلم فلان
      RegExp(r'\bcall\s+(.+)', caseSensitive: false), // call Ahmed
      RegExp(r'\bphone\s+(.+)', caseSensitive: false),
      RegExp(r'\bdial\s+(.+)', caseSensitive: false),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(normalized);
      if (match != null) return match.group(1)?.trim();
    }
    return null;
  }

  /// Fuzzy-matches [spokenName] against the on-device contact list, fully
  /// offline (fuzzywuzzy's string-similarity scoring — no cloud NLP).
  Future<List<ContactMatch>> findMatches(String spokenName, {int minScore = 60}) async {
    if (!await _ensurePermissions()) {
      throw StateError('Contacts/Phone permission not granted.');
    }

    final contacts = await _loadContacts();
    final scored = <ContactMatch>[];

    for (final contact in contacts) {
      final displayName = contact.displayName;
      if (displayName.isEmpty) continue;

      final ratio = weightedRatio(spokenName.toLowerCase(), displayName.toLowerCase());
      if (ratio >= minScore) {
        scored.add(ContactMatch(contact, ratio));
      }
    }

    scored.sort((a, b) => b.score.compareTo(a.score));
    return scored;
  }

  /// Full pipeline: takes a raw voice command, resolves the best contact
  /// match, and places a direct call (bypassing the dialer UI) via a native
  /// Android Intent.ACTION_CALL.
  ///
  /// Returns the contact that was called, or null if nothing matched well
  /// enough for a *confident* direct call (caller should then ask the user
  /// to confirm among [ambiguousMatches] instead of guessing).
  Future<Contact?> handleVoiceCallCommand(
    String rawCommand, {
    void Function(List<ContactMatch> ambiguousMatches)? onAmbiguous,
  }) async {
    final name = extractNameFromCommand(rawCommand);
    if (name == null || name.isEmpty) return null;

    final matches = await findMatches(name);
    if (matches.isEmpty) return null;

    // A single, clearly-best match (score gap >= 15 from runner-up, or only
    // one match) is dialed immediately. Otherwise Sai should read the
    // options back to the user rather than guessing who to call.
    final isConfident = matches.length == 1 ||
        (matches[0].score - matches[1].score) >= 15;

    if (!isConfident) {
      onAmbiguous?.call(matches);
      return null;
    }

    final best = matches.first.contact;
    final number = best.phones.isNotEmpty ? best.phones.first.number : null;
    if (number == null) return null;

    await _placeDirectCall(number);
    return best;
  }

  Future<void> _placeDirectCall(String phoneNumber) async {
    // Uses a native Intent.ACTION_CALL under the hood (registered as a
    // <queries> entry in AndroidManifest.xml), which requires CALL_PHONE
    // and dials immediately without opening the dialer app for confirmation.
    await _callChannel.invokeMethod('call', {'number': phoneNumber});
  }
}
