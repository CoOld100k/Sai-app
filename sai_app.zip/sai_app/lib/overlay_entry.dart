import 'package:flutter/material.dart';
import 'overlay_widget.dart';

/// Runs inside the overlay window's own Flutter engine/isolate.
///
/// IMPORTANT: this isolate does NOT share memory with the main app isolate.
/// It talks to the main isolate / background service via
/// `FlutterOverlayWindow.shareData` (for simple state, e.g. "listening"/
/// "speaking"/"idle") and via the platform MethodChannels defined in
/// MainActivity.kt for anything that needs native access.
void runOverlayApp() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      backgroundColor: Colors.transparent,
      home: Material(
        color: Colors.transparent,
        child: SaiOverlayWidget(),
      ),
    ),
  );
}
