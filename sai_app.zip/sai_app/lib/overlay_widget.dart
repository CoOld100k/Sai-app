import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

/// Visual/behavioral state Sai's floating star can be in.
enum SaiState { idle, listening, speaking }

const Color kSaiBlue = Color(0xFF00E5FF);

class SaiOverlayWidget extends StatefulWidget {
  const SaiOverlayWidget({super.key});

  @override
  State<SaiOverlayWidget> createState() => _SaiOverlayWidgetState();
}

class _SaiOverlayWidgetState extends State<SaiOverlayWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  SaiState _state = SaiState.idle;
  StreamSubscription? _dataSub;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();

    // The main isolate / background service pushes state changes here, e.g.
    // FlutterOverlayWindow.shareData({'state': 'listening'});
    _dataSub = FlutterOverlayWindow.overlayListener.listen((event) {
      if (event is Map && event['state'] is String) {
        final next = SaiState.values.firstWhere(
          (s) => s.name == event['state'],
          orElse: () => SaiState.idle,
        );
        setState(() => _state = next);
      }
    });
  }

  @override
  void dispose() {
    _dataSub?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onTap() {
    // Tapping the star while idle opens the main app / a quick chat sheet;
    // tapping while listening cancels listening. Wire this to a MethodChannel
    // call into the background service as needed.
    FlutterOverlayWindow.shareData({'action': 'tap', 'from': 'overlay'});
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _onTap,
      onPanUpdate: (details) {
        // Allow the user to drag the star around the screen.
        FlutterOverlayWindow.moveOverlay(
          OverlayPosition(details.globalPosition.dx, details.globalPosition.dy),
        );
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          return CustomPaint(
            size: const Size(140, 140),
            painter: _SaiStarPainter(
              progress: _controller.value,
              state: _state,
            ),
          );
        },
      ),
    );
  }
}

class _SaiStarPainter extends CustomPainter {
  final double progress; // 0.0 -> 1.0, loops
  final SaiState state;

  _SaiStarPainter({required this.progress, required this.state});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final baseRadius = size.shortestSide * 0.28;

    switch (state) {
      case SaiState.idle:
        _paintIdlePulse(canvas, center, baseRadius);
        break;
      case SaiState.listening:
        _paintListeningRipple(canvas, center, baseRadius);
        break;
      case SaiState.speaking:
        _paintSpeakingGlow(canvas, center, baseRadius);
        break;
    }

    _paintStar(canvas, center, baseRadius, _glowIntensityFor(state));
  }

  /// Slow, gentle breathing glow when Sai is just present and waiting.
  void _paintIdlePulse(Canvas canvas, Offset center, double radius) {
    final t = (math.sin(progress * 2 * math.pi) + 1) / 2; // 0..1
    final glowRadius = radius * (1.3 + 0.25 * t);
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [kSaiBlue.withOpacity(0.35 * t + 0.1), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: glowRadius))
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, glowRadius, paint);
  }

  /// Expanding concentric rings, like sound waves, while Sai is listening.
  void _paintListeningRipple(Canvas canvas, Offset center, double radius) {
    for (int i = 0; i < 3; i++) {
      final ringProgress = (progress + i / 3) % 1.0;
      final ringRadius = radius * (1.0 + ringProgress * 1.8);
      final opacity = (1.0 - ringProgress).clamp(0.0, 1.0) * 0.6;
      final paint = Paint()
        ..color = kSaiBlue.withOpacity(opacity)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5;
      canvas.drawCircle(center, ringRadius, paint);
    }
  }

  /// Fast, brighter flicker synced to a fake "amplitude" while Sai talks.
  /// In production, feed this from the TTS engine's audio amplitude stream.
  void _paintSpeakingGlow(Canvas canvas, Offset center, double radius) {
    final flicker = 0.6 + 0.4 * math.sin(progress * 2 * math.pi * 6).abs();
    final glowRadius = radius * (1.4 + 0.5 * flicker);
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [kSaiBlue.withOpacity(0.55 * flicker), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: glowRadius))
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, glowRadius, paint);
  }

  double _glowIntensityFor(SaiState state) {
    switch (state) {
      case SaiState.idle:
        return 0.7;
      case SaiState.listening:
        return 0.9;
      case SaiState.speaking:
        return 1.0;
    }
  }

  /// Draws the 8-pointed sky-blue star itself.
  void _paintStar(Canvas canvas, Offset center, double radius, double glow) {
    final path = Path();
    const points = 8;
    final outerR = radius;
    final innerR = radius * 0.45;

    for (int i = 0; i < points * 2; i++) {
      final isOuter = i.isEven;
      final r = isOuter ? outerR : innerR;
      final angle = (math.pi / points) * i - math.pi / 2;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();

    final fillPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.white, kSaiBlue],
        stops: const [0.0, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: outerR))
      ..style = PaintingStyle.fill
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2 * glow);

    canvas.drawPath(path, fillPaint);

    final strokePaint = Paint()
      ..color = kSaiBlue.withOpacity(0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawPath(path, strokePaint);
  }

  @override
  bool shouldRepaint(covariant _SaiStarPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.state != state;
}
