import 'package:flutter_tts/flutter_tts.dart';

/// Wraps Android's on-device TTS engine for Sai's voice output.
///
/// `flutter_tts` uses the system's already-installed TTS engine (e.g. Google
/// Speech Services' on-device voices) — as long as the user has downloaded
/// the offline Arabic/English voice packs in Android Settings, synthesis
/// happens fully on-device with no network call from this app.
class TtsService {
  TtsService._();
  static final TtsService instance = TtsService._();

  final FlutterTts _tts = FlutterTts();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;

    // Force on-device synthesis where the engine supports it, so Sai never
    // silently falls back to a network TTS voice.
    await _tts.setSharedInstance(true);
    await _tts.setSpeechRate(0.48);
    await _tts.setPitch(1.02);
    await _tts.setVolume(1.0);
    await _tts.awaitSpeakCompletion(true);

    // Default to Arabic; callers should call setLanguageForText() per
    // message so Sai matches whichever language the user just spoke.
    await _tts.setLanguage('ar-SA');

    _initialized = true;
  }

  /// Picks ar-SA or en-US based on a quick Arabic-script heuristic, so Sai's
  /// voice matches the language of what it's about to say.
  Future<void> _setLanguageForText(String text) async {
    final isArabic = RegExp(r'[\u0600-\u06FF]').hasMatch(text);
    await _tts.setLanguage(isArabic ? 'ar-SA' : 'en-US');
  }

  Future<void> speak(String text) async {
    if (!_initialized) await init();
    await _setLanguageForText(text);
    await _tts.speak(text);
  }

  Future<void> stop() => _tts.stop();

  /// Exposes engine progress so the overlay's "speaking" glow animation can
  /// sync to actual speech timing rather than a fixed guess.
  void onProgress(void Function(String text, int start, int end) callback) {
    _tts.setProgressHandler((text, start, end, word) => callback(text, start, end));
  }

  void onCompletion(void Function() callback) {
    _tts.setCompletionHandler(callback);
  }
}
