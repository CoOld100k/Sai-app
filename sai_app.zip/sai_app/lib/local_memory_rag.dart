import 'dart:io';

import 'package:exif/exif.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:sqflite/sqflite.dart';

enum MemorySource { ocr, exif, conversation, manual }

class MemoryItem {
  final int? id;
  final String content;
  final MemorySource source;
  final DateTime createdAt;
  final double relevance; // filled in only by retrieveRelevant()

  MemoryItem({
    this.id,
    required this.content,
    required this.source,
    required this.createdAt,
    this.relevance = 0,
  });

  Map<String, Object?> toMap() => {
        'content': content,
        'source': source.name,
        'created_at': createdAt.millisecondsSinceEpoch,
      };

  static MemoryItem fromMap(Map<String, Object?> map) => MemoryItem(
        id: map['id'] as int?,
        content: map['content'] as String,
        source: MemorySource.values.firstWhere((s) => s.name == map['source']),
        createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
      );
}

/// Sai's permanent, 100% local long-term memory.
///
/// Two responsibilities:
///  1. Ingestion: scan the user's local photos/notes with on-device ML Kit
///     OCR plus EXIF metadata, and store distilled facts (habits, favorite
///     games, friends' names, preferences) as rows in SQLite.
///  2. Retrieval: a cheap on-device keyword/TF-ish scorer that pulls the
///     most relevant memories for a given user message, to inject into the
///     LLM prompt (see offline_ai_service.dart). No embeddings model is
///     required — this keeps everything fast on low-end phones — but the
///     schema leaves room to add a local embedding column later.
class LocalMemoryRag {
  LocalMemoryRag._();
  static final LocalMemoryRag instance = LocalMemoryRag._();

  Database? _db;
  final _textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);

  Future<void> init() async {
    if (_db != null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(dir.path, 'sai_memory.db');

    _db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            source TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
        // Simple FTS index for fast keyword retrieval without embeddings.
        await db.execute('''
          CREATE VIRTUAL TABLE memories_fts USING fts4(content, content_rowid='id')
        ''');
        await db.execute('''
          CREATE TABLE ingested_assets (
            asset_id TEXT PRIMARY KEY,
            ingested_at INTEGER NOT NULL
          )
        ''');
      },
    );
  }

  Database get _requireDb {
    final db = _db;
    if (db == null) {
      throw StateError('LocalMemoryRag.init() must be awaited before use.');
    }
    return db;
  }

  Future<int> addMemory({
    required String content,
    required MemorySource source,
  }) async {
    final item = MemoryItem(content: content, source: source, createdAt: DateTime.now());
    final id = await _requireDb.insert('memories', item.toMap());
    await _requireDb.rawInsert(
      'INSERT INTO memories_fts (rowid, content) VALUES (?, ?)',
      [id, content],
    );
    return id;
  }

  /// Naive-but-effective local retrieval: FTS match ranked by recency as a
  /// tiebreaker. Good enough for a personal-memory assistant at this scale
  /// (hundreds to low thousands of memories) without needing a vector index.
  Future<List<MemoryItem>> retrieveRelevant(String query, {int limit = 5}) async {
    final terms = query
        .split(RegExp(r'\s+'))
        .where((t) => t.trim().length > 2)
        .map((t) => '$t*')
        .join(' OR ');

    if (terms.isEmpty) return [];

    final rows = await _requireDb.rawQuery('''
      SELECT m.* FROM memories m
      JOIN memories_fts f ON f.rowid = m.id
      WHERE memories_fts MATCH ?
      ORDER BY m.created_at DESC
      LIMIT ?
    ''', [terms, limit]);

    return rows.map(MemoryItem.fromMap).toList();
  }

  Future<List<MemoryItem>> recent({int limit = 50}) async {
    final rows = await _requireDb.query(
      'memories',
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return rows.map(MemoryItem.fromMap).toList();
  }

  // ---------------------------------------------------------------------
  // Ingestion pipeline: local photo OCR + EXIF -> distilled memories
  // ---------------------------------------------------------------------

  /// Scans the device's photo library (already permission-checked by the
  /// caller) and extracts text via on-device ML Kit OCR plus EXIF metadata,
  /// storing anything useful as long-term memory. Designed to run
  /// incrementally — already-ingested assets are skipped via
  /// `ingested_assets`.
  Future<int> ingestRecentPhotos({int maxAssets = 100}) async {
    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth && !permission.hasAccess) return 0;

    final albums = await PhotoManager.getAssetPathList(
      type: RequestType.image,
      onlyAll: true,
    );
    if (albums.isEmpty) return 0;

    final assets = await albums.first.getAssetListRange(start: 0, end: maxAssets);
    var ingestedCount = 0;

    for (final asset in assets) {
      final already = await _requireDb.query(
        'ingested_assets',
        where: 'asset_id = ?',
        whereArgs: [asset.id],
      );
      if (already.isNotEmpty) continue;

      final file = await asset.file;
      if (file != null) {
        await _ingestOcrFromFile(file, assetId: asset.id);
        await _ingestExifFromFile(file, assetId: asset.id);
      }

      await _requireDb.insert('ingested_assets', {
        'asset_id': asset.id,
        'ingested_at': DateTime.now().millisecondsSinceEpoch,
      });
      ingestedCount++;
    }

    return ingestedCount;
  }

  Future<void> _ingestOcrFromFile(File file, {required String assetId}) async {
    try {
      final inputImage = InputImage.fromFile(file);
      final result = await _textRecognizer.processImage(inputImage);
      final text = result.text.trim();
      if (text.length < 8) return; // skip near-empty OCR results

      await addMemory(
        content: 'Found in a local photo/note (asset $assetId): "$text"',
        source: MemorySource.ocr,
      );
    } catch (_) {
      // OCR failures are non-fatal; just skip this asset's text extraction.
    }
  }

  Future<void> _ingestExifFromFile(File file, {required String assetId}) async {
    try {
      final bytes = await file.readAsBytes();
      final tags = await readExifFromBytes(bytes);
      if (tags.isEmpty) return;

      final dateTaken = tags['EXIF DateTimeOriginal']?.printable;
      final gpsLat = tags['GPS GPSLatitude']?.printable;
      final gpsLon = tags['GPS GPSLongitude']?.printable;
      final camera = tags['Image Model']?.printable;

      final facts = <String>[
        if (dateTaken != null) 'taken on $dateTaken',
        if (gpsLat != null && gpsLon != null) 'near coordinates $gpsLat, $gpsLon',
        if (camera != null) 'shot on a $camera',
      ];
      if (facts.isEmpty) return;

      await addMemory(
        content: 'Photo metadata (asset $assetId): ${facts.join(', ')}.',
        source: MemorySource.exif,
      );
    } catch (_) {
      // Missing/corrupt EXIF is common and non-fatal.
    }
  }

  /// Lets the user (or an OCR/EXIF pass) explicitly teach Sai a durable fact,
  /// e.g. "My best friend is Omar" or "I love Connect 4".
  Future<void> rememberFact(String fact) =>
      addMemory(content: fact, source: MemorySource.manual);

  Future<void> dispose() async {
    await _textRecognizer.close();
    await _db?.close();
  }
}
