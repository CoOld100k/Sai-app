import 'package:flutter/services.dart';

/// A single point on a game board, mapped to real screen coordinates.
class BoardCell {
  final int row;
  final int col;
  final double screenX;
  final double screenY;
  const BoardCell(this.row, this.col, this.screenX, this.screenY);
}

/// Bridges Dart game-playing logic to the native `GameAccessibilityService`,
/// which performs the actual `dispatchGesture` taps/swipes on-screen.
///
/// This class intentionally contains NO game strategy — it only knows how to
/// turn "tap cell (r, c)" into a real physical tap. Game logic (e.g. a
/// minimax Tic-Tac-Toe solver or a Connect 4 heuristic) lives separately and
/// calls into this service once it has decided a move.
class GameTouchService {
  GameTouchService._();
  static final GameTouchService instance = GameTouchService._();

  static const _channel = MethodChannel('com.sai.app/game_touch');

  Future<bool> get isAccessibilityEnabled async {
    final enabled = await _channel.invokeMethod<bool>('isAccessibilityEnabled');
    return enabled ?? false;
  }

  /// Opens Android's Accessibility settings screen so the user can manually
  /// flip Sai's "Game Assist" service on — this cannot be done
  /// programmatically, by OS design.
  Future<void> requestAccessibilityEnable() async {
    await _channel.invokeMethod('openAccessibilitySettings');
  }

  Future<bool> tap(double x, double y, {int durationMs = 80}) async {
    if (!await isAccessibilityEnabled) return false;
    final ok = await _channel.invokeMethod<bool>('tap', {
      'x': x,
      'y': y,
      'durationMs': durationMs,
    });
    return ok ?? false;
  }

  Future<bool> swipe(
    double x1,
    double y1,
    double x2,
    double y2, {
    int durationMs = 200,
  }) async {
    if (!await isAccessibilityEnabled) return false;
    final ok = await _channel.invokeMethod<bool>('swipe', {
      'x1': x1,
      'y1': y1,
      'x2': x2,
      'y2': y2,
      'durationMs': durationMs,
    });
    return ok ?? false;
  }

  Future<bool> tapCell(BoardCell cell) => tap(cell.screenX, cell.screenY);

  /// Plays a short delay between two rapid taps so Android doesn't collapse
  /// them into a single event — useful for "select piece, then confirm".
  Future<void> tapThenTap(BoardCell first, BoardCell second, {int delayMs = 300}) async {
    await tapCell(first);
    await Future.delayed(Duration(milliseconds: delayMs));
    await tapCell(second);
  }
}

/// Example calibration helper: maps a 3x3 Tic-Tac-Toe grid drawn on-screen
/// between two known corner points to real tap coordinates. Real usage would
/// calibrate this once per game via a short on-screen "tap the corners"
/// setup flow, then persist it (e.g. in SharedPreferences).
class TicTacToeBoardMapper {
  final double topLeftX, topLeftY, bottomRightX, bottomRightY;

  const TicTacToeBoardMapper({
    required this.topLeftX,
    required this.topLeftY,
    required this.bottomRightX,
    required this.bottomRightY,
  });

  BoardCell cellAt(int row, int col) {
    final cellW = (bottomRightX - topLeftX) / 3;
    final cellH = (bottomRightY - topLeftY) / 3;
    final x = topLeftX + cellW * (col + 0.5);
    final y = topLeftY + cellH * (row + 0.5);
    return BoardCell(row, col, x, y);
  }
}
