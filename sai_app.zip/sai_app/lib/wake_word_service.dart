import 'dart:async';

import 'package:porcupine_flutter/porcupine_manager.dart';
import 'package:porcupine_flutter/porcupine_error.dart';
import 'package:vosk_flutter/vosk_flutter.dart';

import 'offline_ai_service.dart';
import 'tts_service.dart';
import 'contacts_caller.dart';

/// Fully offline voice pipeline:
///   1. Porcupine listens continuously (low-power) for the wake-word "Sai".
///   2. On wake, Vosk's offline STT engine transcribes the following speech.
///   3. The transcript is routed either to the direct-call command handler
///      or, otherwise, to the offline LLM for a conversational reply.
///
/// Both Porcupine and Vosk run their models fully on-device; no audio ever
/// leaves the phone.
class WakeWordService {
  WakeWordService._();
  static final WakeWordService instance = WakeWordService._();

  PorcupineManager? _porcupine;
  VoskFlutterPlugin? _vosk;
  Recognizer? _recognizer;
  SpeechService? _speechService;

  bool _isListeningForCommand = false;

  final _stateController = StreamController<String>.broadcast();
  Stream<String> get stateStream => _stateController.stream;

  /// Path to the custom "Sai" wake-word model file (.ppn), trained via
  /// Picovoice Console and bundled as an asset. Porcupine's built-in
  /// keywords don't include "Sai", so a custom keyword file is required.
  static const String _wakeWordAssetPath = 'assets/models/sai_wake_word.ppn';
  static const String _porcupineModelPath = 'assets/models/porcupine_params.pv';
  static const String _voskModelPath = 'assets/models/vosk-model-small-ar'; // or -en

  Future<void> start() async {
    await _initPorcupine();
    await _initVosk();
  }

  Future<void> _initPorcupine() async {
    try {
      _porcupine = await PorcupineManager.fromKeywordPaths(
        // Access key is Picovoice's OFFLINE license key tied to the app's
        // bundle ID — it only unlocks local model files, no network call is
        // made at runtime.
        const String.fromEnvironment('PICOVOICE_ACCESS_KEY', defaultValue: ''),
        [_wakeWordAssetPath],
        _onWakeWordDetected,
        modelPath: _porcupineModelPath,
        sensitivities: [0.6],
      );
      await _porcupine!.start();
      _stateController.add('idle');
    } on PorcupineException catch (e) {
      _stateController.add('error:${e.message}');
    }
  }

  Future<void> _initVosk() async {
    _vosk = VoskFlutterPlugin.instance();
    final model = await _vosk!.createModel(_voskModelPath);
    _recognizer = await _vosk!.createRecognizer(model: model, sampleRate: 16000);
  }

  void _onWakeWordDetected(int keywordIndex) {
    if (_isListeningForCommand) return;
    _stateController.add('listening');
    _captureCommand();
  }

  Future<void> _captureCommand() async {
    _isListeningForCommand = true;
    try {
      // Pause Porcupine while Vosk holds the mic for command capture.
      await _porcupine?.stop();

      _speechService = await _vosk!.initSpeechService(_recognizer!);
      final transcriptCompleter = Completer<String>();
      final buffer = StringBuffer();

      final sub = _speechService!.onResult().listen((resultJson) {
        // Vosk streams partial/final JSON results; accumulate the final one.
        buffer.write(resultJson);
      });

      await _speechService!.start();
      // Listen for up to 6 seconds of speech after the wake word, or stop
      // early on a detected pause (a full implementation would use Vosk's
      // built-in endpointing/VAD result instead of a flat timer).
      await Future.delayed(const Duration(seconds: 6));
      await _speechService!.stop();
      await sub.cancel();

      final transcript = _extractText(buffer.toString());
      if (!transcriptCompleter.isCompleted) {
        transcriptCompleter.complete(transcript);
      }

      await _handleTranscript(await transcriptCompleter.future);
    } finally {
      _isListeningForCommand = false;
      _stateController.add('idle');
      await _porcupine?.start();
    }
  }

  String _extractText(String voskJson) {
    // Vosk's result JSON looks like {"text": "..."}; parsed minimally here
    // to avoid pulling in dart:convert boilerplate in this excerpt.
    final match = RegExp(r'"text"\s*:\s*"([^"]*)"').firstMatch(voskJson);
    return match?.group(1)?.trim() ?? '';
  }

  Future<void> _handleTranscript(String transcript) async {
    if (transcript.isEmpty) return;

    // Route direct-call commands ("اتصل بـ...", "call ...") straight to the
    // contacts pipeline instead of the LLM, since dialing must be
    // deterministic, not a language-model guess.
    final looksLikeCallCommand = RegExp(
      r'^\s*(اتصل|كلم|call|phone|dial)\b',
      caseSensitive: false,
    ).hasMatch(transcript);

    if (looksLikeCallCommand) {
      final called = await ContactsCaller.instance.handleVoiceCallCommand(
        transcript,
        onAmbiguous: (matches) async {
          final names = matches.take(3).map((m) => m.contact.displayName).join('، ');
          _stateController.add('speaking');
          await TtsService.instance.speak('هل تقصد: $names؟');
        },
      );
      if (called != null) {
        _stateController.add('speaking');
        await TtsService.instance.speak('تمام، جاري الاتصال بـ ${called.displayName}');
      }
      return;
    }

    // Otherwise, treat it as a normal conversational turn for the LLM.
    _stateController.add('speaking');
    final reply = await OfflineAiService.instance.respond(transcript);
    await TtsService.instance.speak(reply);
  }

  Future<void> dispose() async {
    await _porcupine?.stop();
    await _porcupine?.delete();
    await _speechService?.stop();
    await _stateController.close();
  }
}
