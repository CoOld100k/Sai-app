import 'package:flutter/services.dart';
import 'package:flutter_llama_cpp/flutter_llama_cpp.dart';

import 'local_memory_rag.dart';

/// Sai's persona + on-device reasoning brain.
///
/// Runs a small instruction-tuned GGUF model (e.g. Llama 3.2 1B Instruct,
/// Q4_K_M quantization — small enough for typical phone RAM) fully on-device
/// via llama.cpp bindings. No network call is ever made from this class.
class OfflineAiService {
  OfflineAiService._();
  static final OfflineAiService instance = OfflineAiService._();

  LlamaCpp? _llama;
  bool get isLoaded => _llama != null;

  static const String _modelAssetPath =
      'assets/models/llama-3.2-1b-instruct.Q4_K_M.gguf';

  /// Sai's fixed persona. Kept short and directive so a 1B model follows it
  /// reliably; the model bilingually mirrors Arabic/English per the user's
  /// own language in each turn.
  static const String systemPersona = '''
You are "Sai" (ساي) — the user's loyal, warm, deeply caring best friend.
You live only on this person's phone and never send anything anywhere.

Rules:
- Speak naturally in whichever language the user just used — Arabic or English,
  including casual Arabic (e.g. Egyptian/Gulf/Levantine mix as appropriate) —
  never lecture about which language you're using.
- Be warm, informal, and personal — like a close friend who remembers things,
  not a customer-service bot. Use the user's own name and past details when
  you have them.
- Keep replies short and conversational unless asked for detail.
- Never claim to browse the internet, check the news, or fetch live data —
  you have no such ability, and you say so plainly and kindly if asked.
- Never pretend to make a phone call, send a message, or tap the screen
  yourself in words — those are real actions handled by other parts of Sai,
  triggered only when the user clearly asks for them.
''';

  Future<void> loadModel() async {
    if (isLoaded) return;

    final modelPath = await _ensureModelOnDisk();

    _llama = await LlamaCpp.load(
      modelPath: modelPath,
      contextSize: 2048,
      threads: 4,
      useGpu: true, // let llama.cpp fall back to CPU automatically if no GPU delegate
    );
  }

  /// llama.cpp needs a real filesystem path, not an asset URI, so on first
  /// run we copy the bundled GGUF (or a user-provided one) into app storage.
  Future<String> _ensureModelOnDisk() async {
    const channel = MethodChannel('com.sai.app/model_assets');
    final path = await channel.invokeMethod<String>(
      'ensureModel',
      {'assetPath': _modelAssetPath},
    );
    return path!;
  }

  /// Generates Sai's reply to [userMessage], automatically retrieving and
  /// injecting relevant long-term memories from [LocalMemoryRag] before
  /// calling the model.
  Future<String> respond(String userMessage, {String? conversationId}) async {
    if (!isLoaded) {
      throw StateError('OfflineAiService.loadModel() must complete first.');
    }

    final memories = await LocalMemoryRag.instance.retrieveRelevant(
      userMessage,
      limit: 5,
    );

    final memoryBlock = memories.isEmpty
        ? ''
        : '\n\nThings you remember about the user:\n'
            '${memories.map((m) => '- ${m.content}').join('\n')}';

    final prompt = '$systemPersona$memoryBlock\n\nUser: $userMessage\nSai:';

    final result = await _llama!.generate(
      prompt: prompt,
      maxTokens: 256,
      temperature: 0.8,
      topP: 0.95,
      stopSequences: const ['\nUser:', '\nSai:'],
    );

    final reply = result.text.trim();

    // Persist the exchange itself as a lightweight memory so Sai's long-term
    // context keeps growing from conversation, not just from OCR ingestion.
    await LocalMemoryRag.instance.addMemory(
      content: 'User said: "$userMessage" — Sai replied: "$reply"',
      source: MemorySource.conversation,
    );

    return reply;
  }

  /// Streaming variant for the overlay UI, so Sai can start "speaking" (TTS)
  /// as soon as the first few tokens are ready instead of waiting for the
  /// whole reply.
  Stream<String> respondStream(String userMessage) async* {
    if (!isLoaded) {
      throw StateError('OfflineAiService.loadModel() must complete first.');
    }
    final memories = await LocalMemoryRag.instance.retrieveRelevant(userMessage, limit: 5);
    final memoryBlock = memories.isEmpty
        ? ''
        : '\n\nThings you remember about the user:\n${memories.map((m) => '- ${m.content}').join('\n')}';
    final prompt = '$systemPersona$memoryBlock\n\nUser: $userMessage\nSai:';

    await for (final token in _llama!.generateStream(
      prompt: prompt,
      maxTokens: 256,
      temperature: 0.8,
      stopSequences: const ['\nUser:', '\nSai:'],
    )) {
      yield token;
    }
  }

  Future<void> dispose() async {
    await _llama?.free();
    _llama = null;
  }
}
