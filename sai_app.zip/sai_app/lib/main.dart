import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';

import 'overlay_entry.dart'; // defines @pragma('vm:entry-point') overlayMain()
import 'local_memory_rag.dart';
import 'offline_ai_service.dart';
import 'wake_word_service.dart';
import 'tts_service.dart';

// The overlay isolate's entry point must be a *top-level* function annotated
// with vm:entry-point so the AOT compiler doesn't tree-shake it away, and it
// must be reachable from this file per flutter_overlay_window's requirements.
@pragma('vm:entry-point')
void overlayMain() => runOverlayApp();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SaiApp());
}

class SaiApp extends StatelessWidget {
  const SaiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sai',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        colorSchemeSeed: const Color(0xFF00E5FF),
        scaffoldBackgroundColor: const Color(0xFF0B0F14),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _initializing = false;
  String _status = 'Sai is asleep.';

  Future<void> _setupAndLaunch() async {
    setState(() {
      _initializing = true;
      _status = 'Requesting permissions…';
    });

    // 1. Runtime permissions — each requested with an explicit rationale in the UI
    //    shown to the user before this call (omitted here for brevity).
    await [
      Permission.microphone,
      Permission.contacts,
      Permission.phone,
      Permission.photos, // maps to READ_MEDIA_IMAGES on Android 13+
      Permission.notification,
    ].request();

    if (!await FlutterOverlayWindow.isPermissionGranted()) {
      setState(() => _status = 'Waiting for "draw over other apps" permission…');
      await FlutterOverlayWindow.requestPermission();
    }

    // 2. Local memory DB (SQLite) — safe to call repeatedly, it's idempotent.
    setState(() => _status = 'Waking up local memory…');
    await LocalMemoryRag.instance.init();

    // 3. Load the on-device LLM (GGUF via llama.cpp). This can take a few
    //    seconds on first run while the model is memory-mapped.
    setState(() => _status = 'Loading Sai\'s brain (offline LLM)…');
    await OfflineAiService.instance.loadModel();

    // 4. Prime the offline TTS engine (downloads NOTHING — uses the on-device
    //    Arabic/English voice packs already installed with the system,
    //    or a bundled offline voice if using a native TTS engine).
    await TtsService.instance.init();

    // 5. Start the always-listening wake-word engine ("Sai") in the background
    //    service so it keeps running even if this Activity is closed.
    setState(() => _status = 'Listening for "Sai"…');
    await WakeWordService.instance.start();

    // 6. Show the floating star overlay across all apps.
    await FlutterOverlayWindow.showOverlay(
      height: 140,
      width: 140,
      alignment: OverlayAlignment.centerRight,
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilityPublic,
      positionGravity: PositionGravity.auto,
      overlayTitle: 'Sai',
      overlayContent: 'Sai is watching over your apps',
    );

    setState(() {
      _initializing = false;
      _status = 'Sai is active and floating over your apps.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const _SaiStarPreview(),
                const SizedBox(height: 24),
                const Text(
                  'Sai',
                  style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(_status, textAlign: TextAlign.center),
                const SizedBox(height: 32),
                FilledButton.icon(
                  onPressed: _initializing ? null : _setupAndLaunch,
                  icon: _initializing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.auto_awesome),
                  label: Text(_initializing ? 'Waking Sai…' : 'Activate Sai'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SaiStarPreview extends StatelessWidget {
  const _SaiStarPreview();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 96,
      height: 96,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: Color(0x8000E5FF), blurRadius: 40, spreadRadius: 4),
        ],
      ),
      child: const Icon(Icons.star, size: 72, color: Color(0xFF00E5FF)),
    );
  }
}
