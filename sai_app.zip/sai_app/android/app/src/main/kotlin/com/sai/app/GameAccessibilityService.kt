package com.sai.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Sai's game-assist service.
 *
 * Purpose: simulate the physical taps/swipes a human player would make on
 * simple, local, turn-based 2-player games (Tic-Tac-Toe, Connect 4, Ludo)
 * so Sai can play as "Player 2" when the user asks it to.
 *
 * This service performs NO autonomous reading of arbitrary app content beyond
 * standard window-state events, and never runs unless:
 *   1. the user has manually enabled it in Android Settings > Accessibility, and
 *   2. Sai's Dart layer explicitly invokes a tap/swipe in direct response to a
 *      user request (see game_touch_service.dart).
 */
class GameAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "SaiGameAssist"

        @Volatile
        var instance: GameAccessibilityService? = null

        /** True once the OS has actually connected this service. */
        val isRunning: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "GameAccessibilityService connected")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally minimal: Sai does not scrape screen content here.
        // A future board-recognition module could read the window's node
        // tree from `event.source` / `rootInActiveWindow`, but that is out
        // of scope for the tap-automation feature and is not implemented,
        // to keep this service's footprint auditable and privacy-respecting.
    }

    override fun onInterrupt() {
        Log.w(TAG, "GameAccessibilityService interrupted")
    }

    /**
     * Dispatches a single tap gesture at (x, y).
     * Returns false immediately if the OS version doesn't support gestures
     * (API < 24) or if dispatch is rejected.
     */
    fun performTap(x: Float, y: Float, durationMs: Long = 80): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Tap completed at ($x, $y)")
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(TAG, "Tap cancelled at ($x, $y)")
            }
        }, null)
    }

    /** Dispatches a swipe/drag gesture from (x1, y1) to (x2, y2), e.g. for a Ludo dice drag. */
    fun performSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 200): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        return dispatchGesture(gesture, null, null)
    }

    /**
     * Dispatches a short sequence of taps with delays between them — useful for
     * e.g. placing an "O" then confirming a dialog in Tic-Tac-Toe.
     */
    fun performTapSequence(points: List<Triple<Float, Float, Long>>): Boolean {
        if (points.isEmpty()) return false
        val builder = GestureDescription.Builder()
        var startTime = 0L
        for ((x, y, delayAfterMs) in points) {
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, startTime, 60))
            startTime += 60 + delayAfterMs
        }
        return dispatchGesture(builder.build(), null, null)
    }
}
