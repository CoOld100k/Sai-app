package com.sai.app

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    companion object {
        const val GAME_CHANNEL = "com.sai.app/game_touch"
        const val SYSTEM_CHANNEL = "com.sai.app/system"
        const val CALL_CHANNEL = "com.sai.app/direct_call"
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // ---- Game touch automation bridge ----
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, GAME_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isAccessibilityEnabled" -> {
                        result.success(GameAccessibilityService.isRunning)
                    }
                    "openAccessibilitySettings" -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        result.success(null)
                    }
                    "tap" -> {
                        val x = (call.argument<Number>("x") ?: 0).toFloat()
                        val y = (call.argument<Number>("y") ?: 0).toFloat()
                        val durationMs = (call.argument<Number>("durationMs") ?: 80).toLong()
                        val ok = GameAccessibilityService.instance?.performTap(x, y, durationMs) ?: false
                        result.success(ok)
                    }
                    "swipe" -> {
                        val x1 = (call.argument<Number>("x1") ?: 0).toFloat()
                        val y1 = (call.argument<Number>("y1") ?: 0).toFloat()
                        val x2 = (call.argument<Number>("x2") ?: 0).toFloat()
                        val y2 = (call.argument<Number>("y2") ?: 0).toFloat()
                        val durationMs = (call.argument<Number>("durationMs") ?: 200).toLong()
                        val ok = GameAccessibilityService.instance
                            ?.performSwipe(x1, y1, x2, y2, durationMs) ?: false
                        result.success(ok)
                    }
                    else -> result.notImplemented()
                }
            }

        // ---- Misc system helpers (overlay permission prompt, etc.) ----
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SYSTEM_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "openOverlaySettings" -> {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:$packageName")
                            )
                        )
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }

        // ---- Direct calling (Intent.ACTION_CALL — dials immediately, no dialer UI) ----
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CALL_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "call" -> {
                        val number = call.argument<String>("number")
                        if (number.isNullOrBlank()) {
                            result.error("NO_NUMBER", "No phone number provided", null)
                            return@setMethodCallHandler
                        }

                        val hasPermission = ContextCompat.checkSelfPermission(
                            this, android.Manifest.permission.CALL_PHONE
                        ) == PackageManager.PERMISSION_GRANTED

                        if (!hasPermission) {
                            result.error("NO_PERMISSION", "CALL_PHONE not granted", null)
                            return@setMethodCallHandler
                        }

                        try {
                            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            result.success(true)
                        } catch (e: SecurityException) {
                            result.error("CALL_FAILED", e.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
