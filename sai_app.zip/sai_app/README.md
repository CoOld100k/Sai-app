# Sai — 100% Offline AI Companion (Android / Flutter)

Sai is a fully offline, on-device AI companion: floating overlay avatar, local LLM
(GGUF via llama.cpp), local RAG memory (SQLite + ML Kit OCR), offline wake-word +
STT + TTS, contact calling, and an Accessibility-based game-automation module.

## Project Structure

```
sai_app/
├── android/
│   └── app/
│       ├── build.gradle
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── res/xml/accessibility_service_config.xml
│           └── kotlin/com/sai/app/
│               ├── MainActivity.kt
│               └── GameAccessibilityService.kt
├── assets/
│   └── models/                # place llama-3.2-1b-instruct.Q4_K_M.gguf here
│       └── vosk-model-small-ar/  # offline STT model folder (or en)
├── lib/
│   ├── main.dart
│   ├── overlay_widget.dart          # UI painted into the overlay window
│   ├── overlay_entry.dart           # entry point run inside the overlay isolate
│   ├── offline_ai_service.dart      # llama.cpp inference + persona prompt
│   ├── local_memory_rag.dart        # SQLite memory + ML Kit OCR ingestion
│   ├── contacts_caller.dart         # fuzzy contact search + direct dial
│   ├── game_touch_service.dart      # bridge to the AccessibilityService
│   ├── wake_word_service.dart       # Porcupine/Vosk wake-word + STT
│   └── tts_service.dart             # flutter_tts wrapper (ar/en)
├── pubspec.yaml
└── README.md
```

## Key architectural decisions

- **Overlay isolate**: `flutter_overlay_window` runs the floating star in a
  *separate Flutter engine/isolate* (`overlayMain()`), not the main app isolate.
  All heavy work (LLM, DB) lives in the main isolate/background service and is
  reached from the overlay via `FlutterOverlayWindow.shareData` /
  a `MethodChannel` bridged through a foreground `Service`, since two isolates
  can't share Dart objects directly.
- **LLM**: llama.cpp bindings run the GGUF model fully on-device. No network
  calls are ever made — there is intentionally no `http`/`dio` dependency.
- **RAG memory**: OCR + EXIF extraction populate a `memories` table in SQLite.
  Before each LLM turn, `local_memory_rag.dart` does a cheap keyword/embedding
  lookup and injects the top-k memory snippets into the system prompt.
- **Game automation**: a Kotlin `AccessibilityService` exposes
  `dispatchGesture` taps over a `MethodChannel`. This only works for the
  device's *own* simple 2D games and requires the user to manually enable the
  service in Android's Accessibility settings — Android does not allow apps to
  self-grant this permission.
- **Permissions**: all sensitive permissions (`READ_CONTACTS`, `CALL_PHONE`,
  `READ_MEDIA_IMAGES`, `SYSTEM_ALERT_WINDOW`, Accessibility, `RECORD_AUDIO`)
  are requested at runtime with clear rationale dialogs, and `CALL_PHONE`
  requires the user to have explicitly confirmed the callee before dialing.

## Note on the LLM/voice plugins

`flutter_llama_cpp`, Porcupine, and Vosk-Flutter APIs vary between releases.
The code below is written against a stable, representative API shape for each
and isolates every plugin call behind a small wrapper class
(`OfflineAiService`, `WakeWordService`, `TtsService`) so a version bump only
requires touching one file.
